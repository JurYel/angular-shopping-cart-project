export const environment = {
    production: false,
    // json-server
    SERVER_URL: "http://localhost:3000",

    // amazon s3
    ACCESS_KEY: "AKIAXQISFHH2YFJA4EMJ",
    SECRET_ACCESS_KEY: "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",
    BUCKET_NAME: "revalida-angular-shop-app",
    S3_REGION: "ap-southeast-1",
    CLOUDFRONT_DOMAIN: "https://dbfiqowsfx2io.cloudfront.net"
}